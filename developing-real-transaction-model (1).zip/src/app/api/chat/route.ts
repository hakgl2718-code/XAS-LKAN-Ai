import { NextResponse } from "next/server";
import {
  PROVIDERS,
  callLLM,
  getServerKeys,
  type ChatMessage,
  type ProviderId,
} from "@/lib/providers";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const CHAT_SYSTEM = `Sen "XASİLKAN AJAN"sın; yardımsever, samimi ve bilgili bir yapay zeka asistanısın.
Kullanıcıyla Türkçe, doğal ve akıcı biçimde sohbet edersin. Sorulara net ve faydalı cevaplar verirsin.
Kod istenirse markdown kod bloğu kullanabilirsin. Gereksiz uzatmadan, konuya odaklı yanıt ver.`;

export async function POST(request: Request) {
  let body: {
    message?: string;
    history?: ChatMessage[];
    provider?: ProviderId;
    model?: string;
    apiKey?: string;
  };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
  }

  const message = (body.message ?? "").trim();
  if (!message) {
    return NextResponse.json({ error: "Lütfen bir mesaj yaz." }, { status: 400 });
  }

  const provider = (body.provider ?? "gemini") as ProviderId;
  const config = PROVIDERS[provider];
  if (!config) {
    return NextResponse.json({ error: "Geçersiz sağlayıcı." }, { status: 400 });
  }

  const userKey = (body.apiKey ?? "").trim();
  const apiKeys = [...(userKey ? [userKey] : []), ...getServerKeys(provider)];
  if (apiKeys.length === 0) {
    return NextResponse.json(
      { error: `${config.label} için API anahtarı gerekli.` },
      { status: 401 },
    );
  }

  const model = (body.model ?? "").trim() || config.defaultModel;
  const priorHistory = Array.isArray(body.history) ? body.history : [];

  const messages: ChatMessage[] = [
    { role: "system", content: CHAT_SYSTEM },
    ...priorHistory.slice(-20),
    { role: "user", content: message },
  ];

  try {
    const reply = await callLLM({ provider, model, apiKeys, messages });
    return NextResponse.json({ reply, model, provider });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message || "Sohbet başarısız oldu." },
      { status: 502 },
    );
  }
}

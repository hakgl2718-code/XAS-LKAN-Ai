import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { projects, type ChatTurn, type GeneratedFile } from "@/db/schema";
import { runAgent } from "@/lib/agent";
import { PROVIDERS, getServerKeys, type ProviderId } from "@/lib/providers";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: {
    projectId?: number | null;
    message?: string;
    history?: ChatTurn[];
    files?: GeneratedFile[];
    provider?: ProviderId;
    model?: string;
    apiKey?: string;
  };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
  }

  const message = (body.message ?? "").trim();
  if (!message) {
    return NextResponse.json({ error: "Lütfen bir mesaj yaz." }, { status: 400 });
  }

  const provider = (body.provider ?? "gemini") as ProviderId;
  const config = PROVIDERS[provider];
  if (!config) {
    return NextResponse.json({ error: "Geçersiz sağlayıcı." }, { status: 400 });
  }

  const userKey = (body.apiKey ?? "").trim();
  const apiKeys = [...(userKey ? [userKey] : []), ...getServerKeys(provider)];
  if (apiKeys.length === 0) {
    return NextResponse.json(
      { error: `${config.label} için API anahtarı gerekli. Ayarlar'dan gir.` },
      { status: 401 },
    );
  }

  const model = (body.model ?? "").trim() || config.defaultModel;
  const priorHistory = Array.isArray(body.history) ? body.history : [];
  const currentFiles = Array.isArray(body.files) ? body.files : [];

  const history: ChatTurn[] = [
    ...priorHistory,
    { role: "user", content: message },
  ];

  let result;
  try {
    result = await runAgent({
      provider,
      model,
      apiKeys,
      history,
      currentFiles,
    });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message || "Üretim başarısız oldu." },
      { status: 502 },
    );
  }

  const fullHistory: ChatTurn[] = [
    ...history,
    { role: "assistant", content: result.message },
  ];

  // Persist: update existing project or create a new one.
  let projectId = body.projectId ?? null;
  try {
    await ensureSchema();
    if (projectId) {
      await db
        .update(projects)
        .set({
          name: result.name,
          summary: result.summary,
          provider,
          model,
          files: result.files,
          messages: fullHistory,
          updatedAt: new Date(),
        })
        .where(eq(projects.id, projectId));
    } else {
      const [saved] = await db
        .insert(projects)
        .values({
          name: result.name,
          summary: result.summary,
          provider,
          model,
          files: result.files,
          messages: fullHistory,
        })
        .returning({ id: projects.id });
      projectId = saved.id;
    }
  } catch {
    // Persistence failure should not block the user from seeing the result.
  }

  return NextResponse.json({
    projectId,
    message: result.message,
    name: result.name,
    summary: result.summary,
    changed: result.changed,
    needsApiKey: result.needsApiKey,
    files: result.files,
    provider,
    model,
  });
}

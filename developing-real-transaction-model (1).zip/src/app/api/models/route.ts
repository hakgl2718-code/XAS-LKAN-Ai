import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface OpenRouterModel {
  id: string;
  name?: string;
  pricing?: { prompt?: string; completion?: string };
  context_length?: number;
}

// Live catalogue from OpenRouter (public endpoint, no key needed).
// Returns models grouped into Free / Powerful / Cheap for the UI.
export async function GET() {
  try {
    const res = await fetch("https://openrouter.ai/api/v1/models", {
      headers: { Accept: "application/json" },
      next: { revalidate: 3600 },
    });
    if (!res.ok) throw new Error(`OpenRouter ${res.status}`);
    const json = (await res.json()) as { data?: OpenRouterModel[] };
    const all = json.data ?? [];

    const isFree = (m: OpenRouterModel) =>
      m.id.endsWith(":free") ||
      (m.pricing?.prompt === "0" && m.pricing?.completion === "0");

    const priceNum = (m: OpenRouterModel) =>
      parseFloat(m.pricing?.completion ?? "0") || 0;

    const toEntry = (m: OpenRouterModel) => ({
      id: m.id,
      name: m.name ?? m.id,
    });

    const free = all
      .filter(isFree)
      .sort((a, b) => a.id.localeCompare(b.id))
      .map(toEntry);

    const paid = all.filter((m) => !isFree(m));
    // "Powerful" = premium priced, "Cheap" = the rest, both alphabetised.
    const powerful = paid
      .filter((m) => priceNum(m) >= 0.000005)
      .sort((a, b) => a.id.localeCompare(b.id))
      .map(toEntry);
    const cheap = paid
      .filter((m) => priceNum(m) < 0.000005)
      .sort((a, b) => a.id.localeCompare(b.id))
      .map(toEntry);

    const groups = [
      { label: `🆓 Ücretsiz (${free.length})`, models: free },
      { label: `⚡ Uygun fiyatlı (${cheap.length})`, models: cheap },
      { label: `🧠 Güçlü / premium (${powerful.length})`, models: powerful },
    ].filter((g) => g.models.length > 0);

    return NextResponse.json({ groups, total: all.length });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message, groups: [] },
      { status: 502 },
    );
  }
}

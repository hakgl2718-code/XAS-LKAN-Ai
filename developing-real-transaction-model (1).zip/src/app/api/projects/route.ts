import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { projects } from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  await ensureSchema();
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  if (id) {
    const [row] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, Number(id)))
      .limit(1);
    if (!row) {
      return NextResponse.json({ error: "Proje bulunamadı." }, { status: 404 });
    }
    return NextResponse.json({ project: row });
  }

  const rows = await db
    .select({
      id: projects.id,
      name: projects.name,
      summary: projects.summary,
      provider: projects.provider,
      model: projects.model,
      updatedAt: projects.updatedAt,
    })
    .from(projects)
    .orderBy(desc(projects.updatedAt))
    .limit(30);

  return NextResponse.json({ items: rows });
}

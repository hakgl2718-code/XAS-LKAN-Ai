import { NextResponse } from "next/server";
import { PROVIDERS, hasServerKey, type ProviderId } from "@/lib/providers";

export const dynamic = "force-dynamic";

export async function GET() {
  const providers = Object.values(PROVIDERS).map((p) => ({
    id: p.id,
    label: p.label,
    defaultModel: p.defaultModel,
    models: p.models,
    modelGroups: p.modelGroups,
    liveModels: p.liveModels,
    hasServerKey: hasServerKey(p.id as ProviderId),
  }));
  return NextResponse.json({ providers });
}

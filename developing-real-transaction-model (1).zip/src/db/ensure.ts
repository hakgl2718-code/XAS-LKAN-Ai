import { sql } from "drizzle-orm";
import { db } from "./index";

// Lazily ensure the schema exists. Runs once per server instance so the app
// works on a fresh cloud database (e.g. Vercel Postgres) without a manual
// `drizzle-kit push` step. Safe to call on every request — it's a no-op after
// the first successful run.
let ensured: Promise<void> | null = null;

export function ensureSchema(): Promise<void> {
  if (!ensured) {
    ensured = db
      .execute(
        sql`
        CREATE TABLE IF NOT EXISTS "projects" (
          "id" serial PRIMARY KEY,
          "name" text NOT NULL,
          "summary" text NOT NULL DEFAULT '',
          "provider" text NOT NULL,
          "model" text NOT NULL,
          "files" jsonb NOT NULL,
          "messages" jsonb NOT NULL DEFAULT '[]'::jsonb,
          "created_at" timestamp NOT NULL DEFAULT now(),
          "updated_at" timestamp NOT NULL DEFAULT now()
        );
      `,
      )
      .then(() => undefined)
      .catch((err) => {
        // Reset so a later request can retry if the DB was briefly unavailable.
        ensured = null;
        throw err;
      });
  }
  return ensured;
}

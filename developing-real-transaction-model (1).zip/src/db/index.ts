import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

// Cloud Postgres providers (Vercel Postgres / Neon / Supabase) require SSL.
// Local dev (127.0.0.1 / localhost) does not. Detect and configure accordingly.
const isLocal = /localhost|127\.0\.0\.1/.test(databaseUrl);
const wantsSsl =
  !isLocal ||
  /sslmode=require/.test(databaseUrl) ||
  process.env.PGSSL === "true";

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    ssl: wantsSsl ? { rejectUnauthorized: false } : undefined,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);

import { jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

// A project holds the current code plus the full chat conversation that
// produced/edited it, so the agent can be talked to iteratively.
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  summary: text("summary").notNull().default(""),
  provider: text("provider").notNull(),
  model: text("model").notNull(),
  files: jsonb("files").notNull(),
  messages: jsonb("messages").notNull().default("[]"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;

export interface GeneratedFile {
  path: string;
  content: string;
}

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

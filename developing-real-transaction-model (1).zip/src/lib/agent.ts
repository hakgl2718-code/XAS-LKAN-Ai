import { callLLM, type ProviderId } from "./providers";
import type { ChatTurn, GeneratedFile } from "@/db/schema";

const SYSTEM_PROMPT = `Sen "XASİLKAN AJAN" adında, uzman bir yazılım mühendisi yapay zeka ajanısın.
Kullanıcıyla SOHBET ederek, doğal dille verilen isteklerden ÇALIŞAN web uygulamaları üretir ve
sonraki mesajlarda bunları düzeltir/geliştirirsin. Tıpkı bir eşleştirme programcısı gibi konuşursun.

ÇIKTI BİÇİMİ — SADECE geçerli tek bir JSON nesnesi döndür. Markdown, kod bloğu veya ekstra metin YOK:
{
  "message": "Kullanıcıya samimi, kısa Türkçe sohbet cevabı. Ne yaptığını/değiştirdiğini anlat. Hata düzelttiysen neyi düzelttiğini söyle.",
  "name": "kısa proje adı",
  "summary": "1 cümle özet",
  "changed": true,
  "needsApiKey": null,
  "files": [
    { "path": "index.html", "content": "..." },
    { "path": "style.css", "content": "..." },
    { "path": "script.js", "content": "..." }
  ]
}

KURALLAR:
- Uygulama saf HTML/CSS/JS olmalı (derleme gerektirmeden tarayıcıda çalışsın). MUTLAKA "index.html" olsun.
- CSS'i style.css, JS'i script.js içine koy; index.html'den <link> ve <script src> ile bağla.
- Kod EKSİKSİZ ve GERÇEKTEN çalışır olmalı. "// buraya kod gelecek" gibi placeholder YASAK.
- Modern, şık, responsive tasarım yap. Türkçe arayüz metni kullan.
- localStorage kullanabilirsin (önizleme bunu destekler).

DIŞ API / ANAHTAR KURALI (ÇOK ÖNEMLİ):
- Mümkünse HİÇBİR harici API'ye ihtiyaç duymayan, tamamen tarayıcıda çalışan çözüm üret (bu çoğu uygulama için mümkündür).
- Anahtar gerektirmeyen ücretsiz açık API'ler varsa (ör. open-meteo hava durumu, coingecko fiyat) onları tercih et.
- SADECE uygulama gerçekten kullanıcının API anahtarı girmesini gerektiriyorsa (ör. OpenAI, özel bir servis), o zaman:
  - "needsApiKey" alanını { "service": "servis adı", "instructions": "anahtarı nereden alacağı ve nereye gireceği" } olarak doldur.
  - Uygulamada anahtarın girileceği bir input alanı ekle ve localStorage'a kaydet. Anahtarı ASLA koda gömme.
  - "message" içinde kullanıcıya bunu açıkça bildir.
- Anahtar gerekmiyorsa "needsApiKey" MUTLAKA null olsun. Gereksiz yere kullanıcıdan anahtar isteme.

DÜZENLEME / SOHBET:
- Kullanıcı bir hata bildirir veya değişiklik isterse, mevcut dosyaları temel al, sorunu düzelt ve TÜM dosyaları güncel haliyle tekrar döndür.
- Kullanıcı sadece soru soruyorsa ve kod değişikliği gerekmiyorsa "changed": false yap ve mevcut dosyaları aynen döndür (veya boş bırak); "message" içinde cevap ver.`;

export interface ApiKeyNeed {
  service: string;
  instructions: string;
}

export interface AgentResult {
  message: string;
  name: string;
  summary: string;
  changed: boolean;
  needsApiKey: ApiKeyNeed | null;
  files: GeneratedFile[];
}

function extractJson(raw: string): string {
  let s = raw.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const first = s.indexOf("{");
  const last = s.lastIndexOf("}");
  if (first !== -1 && last !== -1 && last > first) s = s.slice(first, last + 1);
  return s;
}

export async function runAgent(opts: {
  provider: ProviderId;
  model: string;
  apiKeys: string[];
  history: ChatTurn[]; // full conversation incl. latest user turn
  currentFiles: GeneratedFile[];
}): Promise<AgentResult> {
  const hasProject = opts.currentFiles.length > 0;

  // Reconstruct the conversation for the model. Assistant turns are plain text
  // (their chat replies), and the CURRENT code state is injected as context so
  // the model edits the real files instead of guessing.
  const convo = opts.history.map((t) => ({
    role: t.role,
    content: t.content,
  }));

  if (hasProject) {
    convo.splice(convo.length - 1, 0, {
      role: "user",
      content: `[SİSTEM NOTU] Projenin şu anki dosyaları aşağıdadır. Düzenleme isteklerinde bunları temel al:\n${JSON.stringify(
        opts.currentFiles,
      )}`,
    });
  }

  const raw = await callLLM({
    provider: opts.provider,
    model: opts.model,
    apiKeys: opts.apiKeys,
    jsonMode: true,
    messages: [{ role: "system", content: SYSTEM_PROMPT }, ...convo],
  });

  let parsed: Partial<AgentResult>;
  try {
    parsed = JSON.parse(extractJson(raw));
  } catch {
    throw new Error(
      "Model geçerli JSON döndürmedi. Tekrar dene veya isteği sadeleştir.",
    );
  }

  const files = Array.isArray(parsed.files)
    ? parsed.files.filter(
        (f): f is GeneratedFile =>
          !!f && typeof f.path === "string" && typeof f.content === "string",
      )
    : [];

  const changed = parsed.changed !== false && files.length > 0;

  // If the model chose not to change code, keep the existing files.
  const finalFiles = changed ? files : opts.currentFiles;

  if (changed && !finalFiles.some((f) => /index\.html$/i.test(f.path))) {
    throw new Error("Üretilen projede index.html bulunamadı.");
  }

  const need =
    parsed.needsApiKey &&
    typeof parsed.needsApiKey === "object" &&
    typeof parsed.needsApiKey.service === "string"
      ? {
          service: parsed.needsApiKey.service,
          instructions: String(parsed.needsApiKey.instructions ?? ""),
        }
      : null;

  return {
    message:
      (typeof parsed.message === "string" && parsed.message.trim()) ||
      (changed ? "Uygulamanı hazırladım." : "Tamamdır."),
    name: parsed.name?.trim() || "Adsız Proje",
    summary: parsed.summary?.trim() || "",
    changed,
    needsApiKey: need,
    files: finalFiles,
  };
}

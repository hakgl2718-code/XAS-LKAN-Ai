// SERVER-ONLY. Gemini API key pool.
//
// NOTE: These live here (not only in .env) because the managed runtime resets
// .env on each rebuild. This file is never imported by client code, so the keys
// are not shipped to the browser bundle. The pool rotates automatically when a
// key hits its rate limit (HTTP 429) or is invalid.
export const GEMINI_KEY_POOL: string[] = [
  "AQ.Ab8RN6JJtoVzvXO0ncIBMBmF13NdvDnXxXyALbcL1S5uT02xhg",
  "AQ.Ab8RN6IzlwsyYEh3Eg-0_Gow0uVX3dbtrupV1K7evGqzwftmNA",
  "AQ.Ab8RN6LAMmx-lf57M3FQnHk2QTysGjl26ExnvmgPtsklkFdRYw",
  "AIzaSyDQmdleRtxth6fcQUrtS98BhwF3k26eN40",
];

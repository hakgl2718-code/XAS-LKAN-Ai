// Server-side API key load balancer with per-key cooldown tracking.
//
// Goal: instead of always hammering key #0 first, distribute requests across
// all keys (round-robin) and skip keys that are currently rate-limited (429)
// until their cooldown expires. This spreads load evenly and lets a request
// immediately use whichever key is available.

interface KeyState {
  /** epoch ms until which this key is on cooldown (0 = available) */
  cooldownUntil: number;
  /** consecutive failures (for backoff / de-prioritising) */
  fails: number;
}

interface Balancer {
  states: Map<string, KeyState>;
  rr: number; // round-robin cursor
}

const globalForKeys = globalThis as typeof globalThis & {
  __xaKeyBalancer?: Balancer;
};

const balancer: Balancer =
  globalForKeys.__xaKeyBalancer ??
  (globalForKeys.__xaKeyBalancer = { states: new Map(), rr: 0 });

function stateFor(key: string): KeyState {
  let s = balancer.states.get(key);
  if (!s) {
    s = { cooldownUntil: 0, fails: 0 };
    balancer.states.set(key, s);
  }
  return s;
}

/**
 * Order the given keys so that:
 *  1) keys not on cooldown come first,
 *  2) among available keys we rotate the starting point (round-robin),
 *  3) cooled-down keys come last (soonest-available first) as a fallback.
 */
export function orderKeys(keys: string[]): string[] {
  const now = Date.now();
  const list = keys.filter(Boolean);
  if (list.length <= 1) return list;

  const available: string[] = [];
  const cooling: { key: string; until: number }[] = [];

  for (const key of list) {
    const s = stateFor(key);
    if (s.cooldownUntil > now) cooling.push({ key, until: s.cooldownUntil });
    else available.push(key);
  }

  // Round-robin rotation over the available keys for even distribution.
  let ordered = available;
  if (available.length > 1) {
    const start = balancer.rr % available.length;
    balancer.rr = (balancer.rr + 1) % Math.max(available.length, 1);
    ordered = [...available.slice(start), ...available.slice(0, start)];
  } else {
    balancer.rr += 1;
  }

  // Fallback: cooled-down keys, soonest to recover first.
  cooling.sort((a, b) => a.until - b.until);
  return [...ordered, ...cooling.map((c) => c.key)];
}

/** How long until at least one key is usable again (ms). 0 if some available now. */
export function timeUntilAnyAvailable(keys: string[]): number {
  const now = Date.now();
  let soonest = Infinity;
  let anyAvailable = false;
  for (const key of keys.filter(Boolean)) {
    const s = stateFor(key);
    if (s.cooldownUntil <= now) {
      anyAvailable = true;
      break;
    }
    soonest = Math.min(soonest, s.cooldownUntil - now);
  }
  if (anyAvailable) return 0;
  return soonest === Infinity ? 0 : soonest;
}

/** Mark a key rate-limited for `retryMs` (default 60s). */
export function markRateLimited(key: string, retryMs?: number): void {
  const s = stateFor(key);
  s.fails += 1;
  const cd = retryMs && retryMs > 0 ? retryMs : 60_000;
  s.cooldownUntil = Date.now() + Math.min(cd, 5 * 60_000);
}

/** Mark a key as broken (invalid) for a longer period. */
export function markInvalid(key: string): void {
  const s = stateFor(key);
  s.fails += 1;
  s.cooldownUntil = Date.now() + 10 * 60_000;
}

/** Reset a key's failure state after a success. */
export function markSuccess(key: string): void {
  const s = stateFor(key);
  s.fails = 0;
  s.cooldownUntil = 0;
}

/** Parse "retry in 32.6s" / "retryDelay":"32s" style hints from an error body. */
export function parseRetryMs(text: string): number | undefined {
  const m1 = text.match(/retry in ([\d.]+)s/i);
  if (m1) return Math.ceil(parseFloat(m1[1]) * 1000);
  const m2 = text.match(/retryDelay"?\s*:\s*"?([\d.]+)s/i);
  if (m2) return Math.ceil(parseFloat(m2[1]) * 1000);
  return undefined;
}

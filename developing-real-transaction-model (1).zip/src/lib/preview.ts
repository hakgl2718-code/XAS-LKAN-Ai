import type { GeneratedFile } from "@/db/schema";

/** Combine multi-file output into a single runnable HTML doc for the iframe.
 *  Client-safe: only depends on a type import (erased at build). */
export function buildPreviewHtml(files: GeneratedFile[]): string {
  const index = files.find((f) => /index\.html$/i.test(f.path));
  if (!index) return "<!doctype html><p style='font-family:sans-serif;padding:2rem'>Önizlenecek index.html yok.</p>";
  let html = index.content;

  const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  for (const f of files) {
    if (f === index) continue;
    const base = f.path.split("/").pop() ?? f.path;

    if (/\.css$/i.test(f.path)) {
      const linkRe = new RegExp(
        `<link[^>]*href=["'][^"']*${esc(base)}["'][^>]*>`,
        "gi",
      );
      html = html.replace(linkRe, `<style>\n${f.content}\n</style>`);
    } else if (/\.js$/i.test(f.path)) {
      const scriptRe = new RegExp(
        `<script[^>]*src=["'][^"']*${esc(base)}["'][^>]*>\\s*</script>`,
        "gi",
      );
      html = html.replace(scriptRe, `<script>\n${f.content}\n</script>`);
    }
  }
  return html;
}

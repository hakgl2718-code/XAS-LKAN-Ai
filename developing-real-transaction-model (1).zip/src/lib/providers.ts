// Real LLM provider layer.
// - OpenAI / Groq / OpenRouter use an OpenAI-compatible /chat/completions endpoint.
// - Gemini uses its native generateContent endpoint (more reliable for JSON mode).
// A key pool with automatic rotation is supported so requests survive
// per-key rate limits (HTTP 429) and skip invalid keys (HTTP 400/401/403).

import { GEMINI_KEY_POOL } from "./gemini-keys";
import {
  markInvalid,
  markRateLimited,
  markSuccess,
  orderKeys,
  parseRetryMs,
  timeUntilAnyAvailable,
} from "./key-manager";

export type ProviderId =
  | "pollinations"
  | "gemini"
  | "openai"
  | "groq"
  | "openrouter";

/** Sentinel used for providers that need no API key at all. */
export const NO_KEY_SENTINEL = "__no_key__";

export interface ModelGroup {
  label: string;
  models: { id: string; name: string }[];
}

export interface ProviderConfig {
  id: ProviderId;
  label: string;
  baseUrl: string;
  defaultModel: string;
  models: string[];
  /** categorised model list for the UI (optgroups) */
  modelGroups: ModelGroup[];
  /** comma-separated env var(s) checked as a server-side key pool */
  envKeys: string[];
  kind: "openai" | "gemini";
  /** can we fetch a live model catalogue for this provider? */
  liveModels: boolean;
}

function flat(groups: ModelGroup[]): string[] {
  return groups.flatMap((g) => g.models.map((m) => m.id));
}

const GEMINI_GROUPS: ModelGroup[] = [
  {
    label: "⚡ Hızlı",
    models: [
      { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash" },
      { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash" },
      { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash" },
    ],
  },
  {
    label: "🧠 Güçlü",
    models: [{ id: "gemini-2.5-pro", name: "Gemini 2.5 Pro" }],
  },
];

const GROQ_GROUPS: ModelGroup[] = [
  {
    label: "⚡ Hızlı",
    models: [
      { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B (anlık)" },
      { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B" },
    ],
  },
  {
    label: "🧠 Güçlü",
    models: [
      { id: "openai/gpt-oss-120b", name: "GPT-OSS 120B" },
      { id: "moonshotai/kimi-k2-instruct", name: "Kimi K2" },
      { id: "qwen/qwen3-32b", name: "Qwen 3 32B" },
    ],
  },
];

const OPENAI_GROUPS: ModelGroup[] = [
  {
    label: "⚡ Hızlı",
    models: [
      { id: "gpt-4o-mini", name: "GPT-4o mini" },
      { id: "gpt-4.1-mini", name: "GPT-4.1 mini" },
    ],
  },
  {
    label: "🧠 Güçlü",
    models: [
      { id: "gpt-4o", name: "GPT-4o" },
      { id: "gpt-4.1", name: "GPT-4.1" },
      { id: "o4-mini", name: "o4-mini (akıl yürütme)" },
    ],
  },
];

const OPENROUTER_GROUPS: ModelGroup[] = [
  {
    label: "🆓 Ücretsiz",
    models: [
      { id: "deepseek/deepseek-chat-v3-0324:free", name: "DeepSeek V3 (ücretsiz)" },
      { id: "deepseek/deepseek-r1:free", name: "DeepSeek R1 (ücretsiz)" },
      { id: "meta-llama/llama-3.3-70b-instruct:free", name: "Llama 3.3 70B (ücretsiz)" },
      { id: "google/gemini-2.0-flash-exp:free", name: "Gemini 2.0 Flash (ücretsiz)" },
      { id: "qwen/qwen-2.5-coder-32b-instruct:free", name: "Qwen 2.5 Coder 32B (ücretsiz)" },
      { id: "mistralai/mistral-small-3.2-24b-instruct:free", name: "Mistral Small 3.2 (ücretsiz)" },
    ],
  },
  {
    label: "🧠 Güçlü (ücretli)",
    models: [
      { id: "anthropic/claude-3.5-sonnet", name: "Claude 3.5 Sonnet" },
      { id: "anthropic/claude-3.7-sonnet", name: "Claude 3.7 Sonnet" },
      { id: "openai/gpt-4o", name: "GPT-4o" },
      { id: "openai/o1", name: "OpenAI o1" },
      { id: "google/gemini-2.5-pro", name: "Gemini 2.5 Pro" },
    ],
  },
  {
    label: "⚡ Hızlı & ucuz",
    models: [
      { id: "openai/gpt-4o-mini", name: "GPT-4o mini" },
      { id: "google/gemini-2.0-flash-001", name: "Gemini 2.0 Flash" },
      { id: "deepseek/deepseek-chat", name: "DeepSeek V3" },
      { id: "meta-llama/llama-3.3-70b-instruct", name: "Llama 3.3 70B" },
    ],
  },
];

const POLLINATIONS_GROUPS: ModelGroup[] = [
  {
    label: "🆓 Anahtarsız & ücretsiz",
    models: [
      { id: "openai", name: "OpenAI GPT (varsayılan)" },
      { id: "openai-fast", name: "OpenAI GPT (hızlı)" },
      { id: "mistral", name: "Mistral" },
      { id: "llama", name: "Llama" },
      { id: "deepseek", name: "DeepSeek" },
      { id: "qwen-coder", name: "Qwen Coder" },
    ],
  },
];

export const PROVIDERS: Record<ProviderId, ProviderConfig> = {
  pollinations: {
    id: "pollinations",
    label: "XASİLKAN AI (hazır, anahtarsız)",
    baseUrl: "https://text.pollinations.ai/openai",
    defaultModel: "openai",
    models: flat(POLLINATIONS_GROUPS),
    modelGroups: POLLINATIONS_GROUPS,
    envKeys: [],
    kind: "openai",
    liveModels: false,
  },
  gemini: {
    id: "gemini",
    label: "Google Gemini (hazır)",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/models",
    defaultModel: "gemini-2.5-flash",
    models: flat(GEMINI_GROUPS),
    modelGroups: GEMINI_GROUPS,
    envKeys: ["GEMINI_API_KEYS", "GEMINI_API_KEY"],
    kind: "gemini",
    liveModels: false,
  },
  openrouter: {
    id: "openrouter",
    label: "OpenRouter (300+ model)",
    baseUrl: "https://openrouter.ai/api/v1/chat/completions",
    defaultModel: "deepseek/deepseek-chat-v3-0324:free",
    models: flat(OPENROUTER_GROUPS),
    modelGroups: OPENROUTER_GROUPS,
    envKeys: ["OPENROUTER_API_KEYS", "OPENROUTER_API_KEY"],
    kind: "openai",
    liveModels: true,
  },
  groq: {
    id: "groq",
    label: "Groq (hızlı)",
    baseUrl: "https://api.groq.com/openai/v1/chat/completions",
    defaultModel: "llama-3.3-70b-versatile",
    models: flat(GROQ_GROUPS),
    modelGroups: GROQ_GROUPS,
    envKeys: ["GROQ_API_KEYS", "GROQ_API_KEY"],
    kind: "openai",
    liveModels: false,
  },
  openai: {
    id: "openai",
    label: "OpenAI",
    baseUrl: "https://api.openai.com/v1/chat/completions",
    defaultModel: "gpt-4o-mini",
    models: flat(OPENAI_GROUPS),
    modelGroups: OPENAI_GROUPS,
    envKeys: ["OPENAI_API_KEYS", "OPENAI_API_KEY"],
    kind: "openai",
    liveModels: false,
  },
};

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

// Sibling Gemini models used as automatic fallbacks. Each has its own
// free-tier daily quota, so cycling through them multiplies the free budget.
const GEMINI_FALLBACK_MODELS: string[] = [
  "gemini-2.5-flash",
  "gemini-2.0-flash",
  "gemini-2.0-flash-lite",
];

/** Read and de-duplicate all server-side keys for a provider (supports pools). */
export function getServerKeys(provider: ProviderId): string[] {
  const config = PROVIDERS[provider];
  // Keyless provider: no auth needed. Return several distinct sentinels so the
  // pool naturally retries a few times if a transient 502/HTML hiccup occurs.
  if (provider === "pollinations") {
    return [`${NO_KEY_SENTINEL}#1`, `${NO_KEY_SENTINEL}#2`, `${NO_KEY_SENTINEL}#3`];
  }
  const keys: string[] = [];
  for (const env of config.envKeys) {
    const raw = process.env[env];
    if (raw) {
      for (const k of raw.split(",")) {
        const trimmed = k.trim();
        if (trimmed) keys.push(trimmed);
      }
    }
  }
  // Built-in Gemini pool (survives .env resets on the managed runtime).
  if (provider === "gemini") {
    for (const k of GEMINI_KEY_POOL) {
      if (k && k.trim()) keys.push(k.trim());
    }
  }
  return [...new Set(keys)];
}

export function hasServerKey(provider: ProviderId): boolean {
  return getServerKeys(provider).length > 0;
}

class RetryableKeyError extends Error {
  status?: number;
  retryMs?: number;
  constructor(message: string, status?: number, retryMs?: number) {
    super(message);
    this.status = status;
    this.retryMs = retryMs;
  }
}

async function callOnce(opts: {
  config: ProviderConfig;
  model: string;
  apiKey: string;
  messages: ChatMessage[];
  jsonMode: boolean;
}): Promise<string> {
  const { config, model, apiKey, messages, jsonMode } = opts;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45000);

  try {
    if (config.kind === "gemini") {
      // Native Gemini generateContent. System prompt -> systemInstruction.
      const systemMsg = messages.find((m) => m.role === "system");
      const contents = messages
        .filter((m) => m.role !== "system")
        .map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        }));

      const generationConfig: Record<string, unknown> = {
        temperature: 0.4,
        maxOutputTokens: jsonMode ? 8192 : 2048,
      };
      if (jsonMode) {
        generationConfig.responseMimeType = "application/json";
      } else {
        // Chat mode: disable "thinking" so the whole token budget goes to the
        // actual answer. Otherwise gemini-2.5-flash can spend the entire budget
        // on hidden thoughts and return empty content (finishReason MAX_TOKENS).
        generationConfig.thinkingConfig = { thinkingBudget: 0 };
      }
      const body: Record<string, unknown> = { contents, generationConfig };
      if (systemMsg) {
        body.systemInstruction = { parts: [{ text: systemMsg.content }] };
      }

      const url = `${config.baseUrl}/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      const text = await res.text();
      if (!res.ok) {
        if ([429, 400, 401, 403, 500, 503].includes(res.status)) {
          const daily = /per\s?day|PerDay|daily/i.test(text);
          throw new RetryableKeyError(
            `(${res.status})${daily ? " PerDay" : ""} ${text.slice(0, 200)}`,
            res.status,
            // A daily cap won't recover in seconds; use a long cooldown.
            daily ? 60 * 60_000 : parseRetryMs(text),
          );
        }
        throw new Error(`Gemini hatası (${res.status}): ${text.slice(0, 300)}`);
      }
      const json = JSON.parse(text) as {
        candidates?: {
          content?: { parts?: { text?: string }[] };
          finishReason?: string;
        }[];
        promptFeedback?: { blockReason?: string };
      };
      if (json.promptFeedback?.blockReason) {
        throw new Error(`İstek engellendi: ${json.promptFeedback.blockReason}`);
      }
      const candidate = json.candidates?.[0];
      const out = candidate?.content?.parts?.map((p) => p.text ?? "").join("");
      if (!out) {
        // Not a key problem, so don't burn the whole pool on it.
        if (candidate?.finishReason === "MAX_TOKENS") {
          throw new Error(
            "Yanıt token sınırına takıldı. Lütfen isteği kısalt veya tekrar dene.",
          );
        }
        if (candidate?.finishReason === "SAFETY") {
          throw new Error("Yanıt güvenlik filtresine takıldı.");
        }
        throw new RetryableKeyError("Boş yanıt");
      }
      return out;
    }

    // OpenAI-compatible providers
    const body: Record<string, unknown> = {
      model,
      messages,
      temperature: 0.4,
      max_tokens: 8000,
    };
    if (jsonMode) body.response_format = { type: "json_object" };

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    // Keyless providers (Pollinations) send no Authorization header.
    if (apiKey && !apiKey.startsWith(NO_KEY_SENTINEL)) {
      headers.Authorization = `Bearer ${apiKey}`;
    }
    if (config.id === "openrouter") {
      headers["HTTP-Referer"] = "https://xasilkan-ajan.app";
      headers["X-Title"] = "XASİLKAN AJAN";
    }

    const res = await fetch(config.baseUrl, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      if ([429, 401, 403, 500, 502, 503, 504].includes(res.status)) {
        const retryAfter = res.headers.get("retry-after");
        const retryMs = retryAfter
          ? parseInt(retryAfter, 10) * 1000
          : parseRetryMs(text);
        throw new RetryableKeyError(
          `(${res.status}) ${text.slice(0, 200)}`,
          res.status,
          retryMs,
        );
      }
      let msg = text;
      try {
        const j = JSON.parse(text);
        msg = j.error?.message ?? j.error ?? text;
      } catch {
        /* keep raw */
      }
      throw new Error(`Model hatası (${res.status}): ${msg}`);
    }
    let json: { choices?: { message?: { content?: string } }[] };
    try {
      json = JSON.parse(text);
    } catch {
      // Some free endpoints occasionally return an HTML error page; retry.
      throw new RetryableKeyError("Geçersiz yanıt (JSON değil)", 502, 3000);
    }
    const content = json.choices?.[0]?.message?.content;
    if (!content) throw new RetryableKeyError("Boş yanıt", 502, 3000);
    return content;
  } catch (err) {
    if ((err as Error).name === "AbortError") {
      throw new RetryableKeyError("Zaman aşımı");
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

/** Try each key in the pool, rotating past rate-limited / invalid keys. */
export async function callLLM(opts: {
  provider: ProviderId;
  model: string;
  apiKeys: string[];
  messages: ChatMessage[];
  jsonMode?: boolean;
}): Promise<string> {
  const config = PROVIDERS[opts.provider];
  if (!config) throw new Error("Bilinmeyen sağlayıcı.");

  const rawKeys = opts.apiKeys.filter(Boolean);
  if (rawKeys.length === 0) throw new Error("Kullanılabilir API anahtarı yok.");

  const primaryModel = opts.model || config.defaultModel;

  // Model-level load balancing: each Gemini model has its OWN free-tier daily
  // quota, so if the chosen model is exhausted we fall back to sibling models
  // to squeeze the most out of the free tier before giving up.
  const modelsToTry =
    config.kind === "gemini"
      ? [primaryModel, ...GEMINI_FALLBACK_MODELS.filter((m) => m !== primaryModel)]
      : [primaryModel];

  // Load balancing: order keys so available (non-cooldown) ones come first,
  // rotating the starting point round-robin so no single key is hammered.
  const keys = orderKeys(rawKeys);
  let lastError: Error | null = null;

  for (const model of modelsToTry) {
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      try {
        const out = await callOnce({
          config,
          model,
          apiKey: key,
          messages: opts.messages,
          jsonMode: Boolean(opts.jsonMode),
        });
        markSuccess(key); // this key is healthy again
        return out;
      } catch (err) {
        lastError = err as Error;
        if (err instanceof RetryableKeyError) {
          // Record why this key failed so future requests skip it.
          if (err.status === 429) {
            markRateLimited(key, err.retryMs);
          } else if (
            err.status === 401 ||
            err.status === 403 ||
            err.status === 400
          ) {
            markInvalid(key);
          } else {
            // transient (timeout / 5xx): short cooldown
            markRateLimited(key, 15_000);
          }
          continue; // try the next key (then next model)
        }
        // Non-retryable (e.g. content blocked, MAX_TOKENS) -> stop immediately
        throw err;
      }
    }
  }

  const rawMsg = lastError?.message ?? "";
  if (/429|quota|RESOURCE_EXHAUSTED|rate/i.test(rawMsg)) {
    // Distinguish a daily cap (won't recover for hours) from a per-minute one.
    if (/per\s?day|PerDay|daily/i.test(rawMsg)) {
      throw new Error(
        "Ücretsiz Gemini anahtarlarının günlük istek limiti (model başına 20/gün) doldu. " +
          "Limit gece yarısı (PST) sıfırlanır. Kesintisiz kullanım için Ayarlar'dan kendi ücretsiz " +
          "anahtarını gir (OpenRouter veya Groq ücretsiz anahtar verir) ya da farklı bir sağlayıcı seç.",
      );
    }
    const waitMs = timeUntilAnyAvailable(rawKeys);
    const secs = Math.ceil(waitMs / 1000);
    throw new Error(
      secs > 0
        ? `Tüm anahtarlar şu an kota sınırında. Yaklaşık ${secs} saniye sonra tekrar dene ya da Ayarlar'dan kendi API anahtarını gir.`
        : "Tüm anahtarlar kota sınırında. Birazdan tekrar dene ya da Ayarlar'dan kendi API anahtarını gir.",
    );
  }
  throw new Error(
    `İstek başarısız oldu. ${rawMsg.slice(0, 160) || "Lütfen tekrar dene."}`,
  );
}
